﻿Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b As Double
        a = Val(TextBox2.Text)
        b = Val(TextBox3.Text)
        TextBox1.Text = a + b


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim a, b As Double
        a = Val(TextBox2.Text)
        b = Val(TextBox3.Text)
        TextBox1.Text = a - b
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim a, b As Double
        a = Val(TextBox2.Text)
        b = Val(TextBox3.Text)
        TextBox1.Text = a * b
    End Sub



    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim a, b As Double
        a = Val(TextBox2.Text)
        b = Val(TextBox3.Text)
        TextBox1.Text = (a / b)


    End Sub
End Class

